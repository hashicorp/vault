import { Factory, association } from 'miragejs';
import { faker } from '@faker-js/faker';

// Seed the faker library to ensure consistent data generation
// Add preceding numbers to secret names to help with testing
faker.seed(12345);
let secretCounter = 0;

const allUsers = new Array(15).fill(null).map(() => crypto.randomUUID());

const getPath = () => {
  return `/${faker.hacker.noun()}/${faker.hacker.noun()}`;
};

export default Factory.extend({
  $cluster: association(),
  secret_type: () =>
    faker.helpers.arrayElement([
      'STATIC_SECRET',
      'DYNAMIC_ROLE',
      'STATIC_ROLE',
      'STATIC_ROLE_ROTATING',
      'ROOT_CREDENTIAL',
      'ROOT_CREDENTIAL_ROTATING',
    ]),
  namespace: () => getPath(),
  mount_path: () => getPath(),
  created_at: () => faker.date.recent({ days: 365 }),
  created_by_id: () => faker.helpers.arrayElement(allUsers),
  config_last_modified_by_id: () => faker.helpers.arrayElement(allUsers),
  config_last_accessed_by_id: () => faker.helpers.arrayElement(allUsers),
  secret_last_modified_by_id: () => faker.helpers.arrayElement(allUsers),
  secret_last_accessed_by_id: () => faker.helpers.arrayElement(allUsers),
  version_count: () => faker.number.int({ min: 1, max: 5 }),
  afterCreate(secret) {
    const scannedAt = faker.datatype.boolean({ probability: 0.8 })
      ? new Date()
      : null;
    const isScanned = secret.$cluster.id.includes('scanned') && scannedAt;
    const startDate = isScanned ? scannedAt : secret.created_at;

    const updates = {
      secret_name:
        `${secretCounter++}-${faker.hacker.adjective()}-${faker.hacker.noun()}`.replace(
          /\s+/g,
          '-',
        ),
      scanned_at: isScanned ? scannedAt : null,
      created_at: isScanned ? null : secret.created_at,
      created_by_id: isScanned ? null : secret.created_by_id,
    };

    // Secret engine assignment based on secret type
    if (secret.secret_type === 'STATIC_SECRET') {
      updates.plugin_name = faker.helpers.arrayElement(['kv-v1', 'kv-v2']);
    } else {
      updates.plugin_name = 'database';
    }

    // Root credentials are never really accessed aside from being created
    if (
      secret.secret_type === 'ROOT_CREDENTIAL' ||
      secret.secret_type === 'ROOT_CREDENTIAL_ROTATING'
    ) {
      updates.secret_last_accessed_at = startDate;
    } else {
      updates.secret_last_accessed_at = faker.datatype.boolean({
        probability: 0.8,
      })
        ? faker.date.between({
            from: startDate,
            to: new Date(),
          })
        : null;
    }

    updates.secret_last_modified_at = faker.datatype.boolean({
      probability: 0.8,
    })
      ? faker.date.between({
          from: startDate,
          to: new Date(),
        })
      : null;

    // ttl/rotation_period/rotation_schedule

    if (secret.secret_type === 'DYNAMIC_ROLE') {
      updates.ttl = {
        max_ttl: faker.helpers.arrayElement([
          '86400s', // 1 day
        ]),
        default_ttl: faker.helpers.arrayElement([
          '3600s', // 1 hour
          '86400s', // 1 day
        ]),
      };
    }

    if (
      secret.secret_type === 'ROOT_CREDENTIAL_ROTATING' ||
      secret.secret_type === 'STATIC_ROLE_ROTATING'
    ) {
      if (faker.datatype.boolean({ probability: 0.5 })) {
        updates.rotation_period = faker.helpers.arrayElement([
          '3600s', // 1 hour
          '86400s', // 1 day
          '604800s', // 1 week
          '2592000s', // 30 days
        ]);

        const now = new Date();
        const maxExpiry = new Date();
        maxExpiry.setSeconds(
          now.getSeconds() + parseInt(updates.rotation_period, 10),
        );
        updates.next_rotation_at = faker.date.between({
          from: now,
          to: maxExpiry,
        });
      } else {
        const scheduleDays = faker.helpers.arrayElement([1, 7, 30]);
        if (scheduleDays === 30) {
          // to avoid issues with months with less than 31 days
          updates.rotation_schedule = '0 0 1 * *'; // monthly
        } else if (scheduleDays === 7) {
          updates.rotation_schedule = '0 0 * * 0'; // weekly
        } else {
          updates.rotation_schedule = '0 0 * * *'; // daily
        }
        const now = new Date();
        const maxExpiry = new Date();
        maxExpiry.setDate(now.getDate() + scheduleDays);
        updates.next_rotation_at = faker.date.between({
          from: now,
          to: maxExpiry,
        });
      }
    }

    if (faker.datatype.boolean({ probability: 0.5 })) {
      updates.secret_deleted_at = faker.date.between({
        from: startDate,
        to: new Date(),
      });
      updates.secret_deleted_by_id = faker.helpers.arrayElement(allUsers);
    }

    updates.config_last_modified_at = faker.date.between({
      from: startDate,
      to: new Date(),
    });

    updates.config_last_accessed_at = faker.date.between({
      from: startDate,
      to: new Date(),
    });

    secret.update(updates);
  },
});
