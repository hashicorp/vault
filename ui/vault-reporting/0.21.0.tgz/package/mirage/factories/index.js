/**
 * Copyright IBM Corp. 2025
 * SPDX-License-Identifier: BUSL-1.1
 */

import vaultReportingSecret from './secret.js';
import vaultReportingSavedView from './saved-view.js';
import vaultReportingCertificate from './certificate.js';

export default {
  'vaultReporting.secret': vaultReportingSecret,
  'vaultReporting.savedView': vaultReportingSavedView,
  'vaultReporting.certificate': vaultReportingCertificate,
};
