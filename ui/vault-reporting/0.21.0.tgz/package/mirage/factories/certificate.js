import { Factory, association } from 'miragejs';
import { faker } from '@faker-js/faker';

const MS_PER_DAY = 24 * 60 * 60 * 1000;

// Seed the faker library to ensure consistent data generation
// Add preceding numbers to secret names to help with testing
faker.seed(12345);

const users = new Array(15).fill(null).map(() => crypto.randomUUID());

const issuers = new Array(5).fill(null).map(() => ({
  issuer_common_name: faker.internet.domainName(),
  issuer_serial_number: faker.string
    .hexadecimal({ length: 16, prefix: '' })
    .toUpperCase(),
  issuer_not_before: faker.date.past({ years: 2 }).toISOString(),
  issuer_not_after: faker.date.future({ years: 2 }).toISOString(),
}));

const key_types = {
  RSA: ['RSA-2048', 'RSA-3072', 'RSA-4096'],
  ECDSA: ['EC-P256', 'EC-P384', 'EC-P521'],
  EdDSA: ['Ed25519'],
};

const getPath = () => {
  return `/${faker.hacker.noun()}/${faker.hacker.noun()}`;
};

/**
 * Helper to generate realistic certificate dates for testing filters.
 * Creates a distribution of certificates:
 * - Recently issued (within past 0-90 days)
 * - Expiring soon (within next 0-365 days)
 * - Normal certificates (issued in past, expiring in future)
 */
const generateCertificateDates = () => {
  // 25% recently issued, 25% expiring soon, 50% normal
  const scenario = faker.helpers.weightedArrayElement([
    { value: 'recent', weight: 25 },
    { value: 'expiring', weight: 25 },
    { value: 'normal', weight: 50 },
  ]);

  let notBefore, notAfter;

  if (scenario === 'recent') {
    // Recently issued certificates (within past 0-90 days)
    notBefore = faker.date.recent({ days: 90 });
    // Valid for 1-2 years from issue date
    notAfter = faker.date.soon({
      days: 365,
      refDate: new Date(notBefore.getTime() + 365 * MS_PER_DAY),
    });
  } else if (scenario === 'expiring') {
    // Certificates expiring soon (within next 0-365 days)
    notAfter = faker.date.soon({ days: 365, refDate: new Date() });
    // Issued 6-18 months ago
    notBefore = faker.date.recent({ days: 540, refDate: new Date() });
  } else {
    // Normal certificates - issued in the past, expiring well in the future
    notBefore = faker.date.recent({ days: 500, refDate: new Date() });
    notAfter = faker.date.soon({
      days: 550,
      refDate: new Date(Date.now() + 180 * MS_PER_DAY),
    });
  }

  return { notBefore, notAfter };
};

export default Factory.extend({
  $cluster: association(),
  common_name: () => faker.internet.domainName(),
  role_name: () => `${faker.hacker.adjective()}-role`,
  certificate_type: () =>
    faker.helpers.arrayElement([
      'CERTIFICATE_TYPE_ROOT',
      'CERTIFICATE_TYPE_INTERMEDIATE',
      'CERTIFICATE_TYPE_LEAF',
    ]),
  namespace: () => getPath(),
  mount_path: () => getPath(),
  mount_accessor: () => `pki_${faker.string.alphanumeric(16)}`,
  plugin_name: () => 'vault-plugin-secrets-pki',
  plugin_type: () => 'pki',
  plugin_version: () => `1.21.builtin+vault`,
  serial_number: () =>
    Array.from({ length: 20 }, () =>
      faker.string.hexadecimal({ length: 2, prefix: '' }).toLowerCase(),
    ).join(':'),
  stored_in_vault: () => faker.datatype.boolean(0.8),
  key_algorithm: () => faker.helpers.arrayElement(['RSA', 'ECDSA', 'EdDSA']),

  afterCreate(certificate) {
    const { notBefore, notAfter } = generateCertificateDates();

    const updates = {
      ...faker.helpers.arrayElement(issuers),
      not_before: notBefore.toISOString(),
      not_after: notAfter.toISOString(),
    };

    // Make a small percentage revoked
    if (faker.datatype.boolean(0.1)) {
      updates.revoked_at = faker.date
        .between({
          from: notBefore,
          to: new Date(),
        })
        .toISOString();
      updates.revoked_by_id = faker.helpers.arrayElement(users);
    } else {
      // Make a small percentage expired (override not_after)
      if (faker.datatype.boolean(0.1)) {
        updates.not_after = faker.date
          .past({ years: 0.5, refDate: new Date() })
          .toISOString();
      }
    }

    updates.key_type = faker.helpers.arrayElement(
      key_types[certificate.key_algorithm],
    );

    certificate.update(updates);
  },
});
