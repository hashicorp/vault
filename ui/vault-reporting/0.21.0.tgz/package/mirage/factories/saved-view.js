import { Factory, association, trait } from 'miragejs';
import { faker } from '@faker-js/faker';

// Seed the faker library to ensure consistent data generation
// Add preceding numbers to secret names to help with testing
faker.seed(12345);

export default Factory.extend({
  $cluster: association(),
  $dashboard: 'default',
  id: () => crypto.randomUUID(),
  name: () => faker.commerce.productName(),
  description: () => faker.lorem.sentence(),
  type: () => faker.helpers.arrayElement(['secret', 'certificate']),
  // filters: () => ({}),
  // columns: () => [],
  // sorting: '',
  secrets_inventory: () => ({}),
  certificates_inventory: () => ({}),
  $order: 1000,
  created_by_id: () => crypto.randomUUID(),
  created_at: () => faker.date.recent({ days: 120 }),
  updated_at: null,
  updated_by_id: null,
  secret: trait({
    afterCreate(savedView) {
      const updates = {
        type: 'secret',
      };
      savedView.update(updates);
    },
  }),
  certificate: trait({
    afterCreate(savedView) {
      const updates = {
        type: 'certificate',
      };
      savedView.update(updates);
    },
  }),
  unusedSecrets: trait({
    afterCreate(savedView) {
      const updates = {
        type: 'secret',
        name: 'Unused secrets',
        description: 'Static secrets that have not been accessed in 90+ days.',
        secrets_inventory: {
          include_deleted: false,
          secret_names: [],
          namespaces: [],
          mount_paths: [],
          plugin_names: [],
          plugin_types: [],
          created_at: null,
          created_by_ids: [],
          config_last_modified_at: null,
          config_last_modified_by_ids: [],
          config_last_accessed_at: null,
          config_last_accessed_by_ids: [],
          config_deleted_at: null,
          config_deleted_by_ids: [],
          secret_last_modified_at: null,
          secret_last_modified_by_ids: [],
          secret_last_accessed_by_ids: [],
          secret_deleted_at: null,
          secret_deleted_by_ids: [],
          expires_or_next_rotation_at: null,
          secret_types: ['STATIC_SECRET'],
          secret_last_accessed_at: {
            operator: 'LESS_THAN',
            relative_to_now: '-7776000s', // 90 days
          },
        },
        sorting: {
          order_by: ['secretLastAccessedAt asc'],
        },
        columns: [
          'secretName',
          'pluginName',
          'namespace',
          'mountPath',
          'createdAt',
          'secretLastAccessedAt',
          'secretLastModifiedAt',
        ],
      };
      savedView.update(updates);
    },
  }),
  longLivedSecrets: trait({
    afterCreate(savedView) {
      const updates = {
        type: 'secret',
        name: 'Long-lived secrets',
        description: 'All secrets that have not been updated in 90+ days.',
        secrets_inventory: {
          include_deleted: false,
          secret_names: [],
          secret_types: [],
          namespaces: [],
          mount_paths: [],
          plugin_names: [],
          plugin_types: [],
          created_at: null,
          created_by_ids: [],
          config_last_modified_at: null,
          config_last_modified_by_ids: [],
          config_last_accessed_at: null,
          config_last_accessed_by_ids: [],
          config_deleted_at: null,
          config_deleted_by_ids: [],
          secret_last_modified_by_ids: [],
          secret_last_accessed_at: {},
          secret_last_accessed_by_ids: [],
          secret_deleted_at: null,
          secret_deleted_by_ids: [],
          expires_or_next_rotation_at: null,
          secret_last_modified_at: {
            operator: 'LESS_THAN',
            relative_to_now: '-7776000s', // 90 days
          },
        },
        sorting: {
          order_by: ['secretLastModifiedAt asc'],
        },
        columns: [
          'secretName',
          'pluginName',
          'namespace',
          'mountPath',
          'createdAt',
          'secretLastAccessedAt',
          'secretLastModifiedAt',
        ],
      };
      savedView.update(updates);
    },
  }),
  upcomingSecretRotations: trait({
    afterCreate(savedView) {
      const updates = {
        type: 'secret',
        name: 'Upcoming secret rotations',
        description:
          'Auto-rotating secrets scheduled to rotate in less than 30 days.',
        secrets_inventory: {
          include_deleted: false,
          secret_names: [],
          secret_types: [],
          namespaces: [],
          mount_paths: [],
          plugin_names: [],
          plugin_types: [],
          created_at: null,
          created_by_ids: [],
          config_last_modified_at: null,
          config_last_modified_by_ids: [],
          config_last_accessed_at: null,
          config_last_accessed_by_ids: [],
          config_deleted_at: null,
          config_deleted_by_ids: [],
          secret_last_modified_at: {},
          secret_last_modified_by_ids: [],
          secret_last_accessed_at: {},
          secret_last_accessed_by_ids: [],
          secret_deleted_at: null,
          secret_deleted_by_ids: [],
          expires_or_next_rotation_at: {
            operator: 'LESS_THAN',
            relative_to_now: '2592000s', // 30 days
          },
        },
        columns: [
          'secretName',
          'pluginName',
          'namespace',
          'mountPath',
          'createdAt',
          'nextRotationAt',
          'renewalPolicy',
        ],
      };
      savedView.update(updates);
    },
  }),
  expiredCertificates: trait({
    afterCreate(savedView) {
      const updates = {
        type: 'certificate',
        name: 'Expired certificates',
        description:
          'Certificates that have passed the designated validity period.',
        certificates_inventory: {
          not_after: {
            operator: 'LESS_THAN',
            relative_to_now: '0s',
          },
        },
        sorting: {
          order_by: ['notAfter asc'],
        },
        columns: [
          'commonName',
          'status',
          'roleName',
          'notAfter',
          'notBefore',
          'issuerCommonName',
        ],
      };
      savedView.update(updates);
    },
  }),
  revokedCertificates: trait({
    afterCreate(savedView) {
      const updates = {
        type: 'certificate',
        name: 'Revoked certificates',
        description:
          'Certificates invalidated by the issuing Certificate Authority.',
        certificates_inventory: {
          revoked_at: {
            operator: 'LESS_THAN',
            relative_to_now: '0s',
          },
        },
        sorting: {
          order_by: ['revokedAt desc'],
        },
        columns: [
          'commonName',
          'status',
          'roleName',
          'notAfter',
          'notBefore',
          'revokedAt',
        ],
      };
      savedView.update(updates);
    },
  }),
});
