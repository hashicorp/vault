import { Model, belongsTo } from 'miragejs';

export default Model.extend({
  $cluster: belongsTo('vault.cluster'),
});
