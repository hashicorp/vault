import vaultReportingSecret from './secret.js';
import vaultReportingSavedView from './saved-view.js';
import vaultReportingCertificate from './certificate.js';

export default {
  'vaultReporting.secret': vaultReportingSecret,
  'vaultReporting.savedView': vaultReportingSavedView,
  'vaultReporting.certificate': vaultReportingCertificate,
};
