import { Response } from 'miragejs';

const getType = (reportType) => {
  return {
    'secrets-inventory': 'secret',
    'certificates-inventory': 'certificate',
  }[reportType];
};

export function createSavedView(schema, request) {
  const clusterId = request.params.clusterId;
  const reportType = request.params.reportType;

  const type = getType(reportType);

  if (!type) {
    return new Response(
      400,
      {},
      {
        code: 3,
        message: `Invalid report type: ${reportType}`,
        details: [
          {
            '@type': 'type.googleapis.com/google.rpc.BadRequest',
            field_violations: [],
          },
        ],
      },
    );
  }

  const cluster = schema['vault.clusters'].findBy({ id: clusterId });
  if (!cluster) {
    return new Response(404, {}, { errors: ['Cluster not found'] });
  }

  const existingViews = schema['vaultReporting.savedViews'].where({
    $clusterId: clusterId,
    type,
  }).models;

  if (existingViews.length >= 8) {
    return new Response(
      400,
      {},
      {
        code: 3,
        message: `Cannot create more than 8 saved views`,
        details: [
          {
            '@type': 'type.googleapis.com/google.rpc.BadRequest',
            field_violations: [],
          },
        ],
      },
    );
  }

  const { saved_view: attrs } = JSON.parse(request.requestBody);
  const existing = existingViews.find((view) => view.name === attrs.name);
  if (existing) {
    return new Response(
      400,
      {},
      {
        code: 3,
        message: `A saved view with the name '${attrs.name}' already exists.`,
        details: [
          {
            '@type': 'type.googleapis.com/google.rpc.BadRequest',
            field_violations: [
              {
                field: 'name',
                description: 'Name must be unique',
              },
            ],
          },
        ],
      },
    );
  }
  const savedView = schema['vaultReporting.savedViews'].create({
    ...attrs,
    $cluster: cluster,
    type,
  });
  return savedView;
}

export function listSavedViews(schema, request) {
  const clusterId = request.params.clusterId;
  const reportType = request.params.reportType;

  const type = getType(reportType);

  if (!type) {
    return new Response(400, {}, { errors: ['Invalid report type'] });
  }
  return schema['vaultReporting.savedViews']
    .where({
      $clusterId: clusterId,
      type,
    })
    .sort((a, b) => a.order - b.order);
}

export function updateSavedView(schema, request) {
  const id = request.params.id;
  const clusterId = request.params.clusterId;
  const reportType = request.params.reportType;
  const { saved_view: attrs } = JSON.parse(request.requestBody);
  const type = getType(reportType);

  const savedView = schema['vaultReporting.savedViews'].find(id);
  if (!savedView) {
    return new Response(404, {}, { errors: ['Saved view not found'] });
  }

  const existingViews = schema['vaultReporting.savedViews'].where({
    $clusterId: clusterId,
    type,
  }).models;
  const existing = existingViews.find(
    (view) => view.name === attrs.name && view.id !== id,
  );
  if (existing) {
    return new Response(
      400,
      {},
      {
        code: 3,
        message: `A saved view with the name '${attrs.name}' already exists.`,
        details: [
          {
            '@type': 'type.googleapis.com/google.rpc.BadRequest',
            field_violations: [
              {
                field: 'name',
                description: 'Name must be unique',
              },
            ],
          },
        ],
      },
    );
  }
  savedView.update(attrs);
  return savedView;
}

export function deleteSavedView(schema, request) {
  const id = request.params.id;
  const savedView = schema['vaultReporting.savedViews'].find(id);
  if (!savedView) {
    return new Response(404, {}, { errors: ['Saved view not found'] });
  }
  savedView.destroy();
  return new Response(200, {}, {});
}

export function reorderSavedViews(schema, request) {
  const clusterId = request.params.clusterId;
  const reportType = request.params.reportType;
  const type = getType(reportType);

  const { saved_view_ids: orderedIds } = JSON.parse(request.requestBody);

  if (!Array.isArray(orderedIds)) {
    return new Response(400, {}, { errors: ['Order must be an array'] });
  }

  const existingViews = schema['vaultReporting.savedViews'].where({
    $clusterId: clusterId,
    type,
  }).models;

  if (orderedIds.length !== existingViews.length) {
    return new Response(
      400,
      {},
      { errors: ['Order length does not match existing views length'] },
    );
  }

  const mismatchedIds = orderedIds.filter(
    (id) => !existingViews.find((view) => view.id === id),
  );
  if (mismatchedIds.length > 0) {
    return new Response(
      400,
      {},
      { errors: ['Order contains invalid saved view IDs'] },
    );
  }

  existingViews.forEach((view) => {
    const order = orderedIds.indexOf(view.id) * 10;
    view.update({ order });
  });

  return listSavedViews.call(this, schema, request);
}
