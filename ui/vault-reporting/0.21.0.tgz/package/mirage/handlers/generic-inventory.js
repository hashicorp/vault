/**
 * Copyright IBM Corp. 2025
 * SPDX-License-Identifier: BUSL-1.1
 */
import { faker } from '@faker-js/faker';

const reportTypePathParamToModel = {
  'secrets-inventory': 'vaultReporting.secrets',
  'certificates-inventory': 'vaultReporting.certificates',
};

const reportTypeQueryParamToModel = {
  REPORT_TYPE_CERTIFICATES: 'vaultReporting.certificates',
  REPORT_TYPE_SECRETS: 'vaultReporting.secrets',
};

// Some filter keys need to be swapped to match the model attribute names, mostly due to pluralization
const filterKeySwaps = {
  'vaultReporting.secrets': {
    plugin_names: 'plugin_name',
    secret_names: 'secret_name',
    secret_types: 'secret_type',
    namespaces: 'namespace',
    mount_paths: 'mount_path',
    created_by_ids: 'created_by_id',
    secret_last_accessed_by_ids: 'secret_last_accessed_by_id',
    secret_last_modified_by_ids: 'secret_last_modified_by_id',
    config_last_modified_by_ids: 'config_last_modified_by_id',
    secret_deleted_by_ids: 'secret_deleted_by_id',
    expires_or_next_rotation_at: 'next_rotation_at',
  },
  'vaultReporting.certificates': {
    certificate_types: 'type',
    namespaces: 'namespace',
    mount_paths: 'mount_path',
    key_algorithms: 'key_algorithm',
    key_types: 'key_type',
    revoked_by_ids: 'revoked_by_id',
    role_names: 'role_name',
  },
};

function parseRelativeDate(relativeDate) {
  const match = relativeDate.match(/^(-?\d+)s$/);
  if (!match) {
    throw new Error(`Invalid relative date format: ${relativeDate}`);
  }
  const seconds = parseInt(match[1], 10);
  const date = new Date();
  date.setSeconds(date.getSeconds() + seconds);
  if (seconds > 0) {
    date.setMilliseconds(999); // Set to end of the second for future dates
  } else {
    date.setMilliseconds(0); // Set to start of the second for past dates
  }

  return date;
}

function getAllRecords(modelName = 'vaultReporting.secrets', schema, request) {
  const { clusterId } = request.params;
  const { data } = this.serialize(
    schema[modelName].where({ $clusterId: clusterId }),
  );

  return data;
}

export function getFilteredRecords(modelName, schema, request) {
  const url = new URL(request.url);
  const params = url.searchParams;
  let data = getAllRecords.call(this, modelName, schema, request);

  const paramKeys = Array.from(new Set(params.keys()));

  const keySwaps = filterKeySwaps[modelName] || {};

  paramKeys.forEach((key) => {
    // handle basic non-date equality filters (dates will be filtered out due to naming convention)
    if (
      key.startsWith('filter.') &&
      !key.endsWith('include_deleted') &&
      !key.endsWith('stored_in_vault') &&
      !key.endsWith('.operator') &&
      !key.endsWith('.absolute') &&
      !key.endsWith('.relative_to_now')
    ) {
      let field = key.replace('filter.', '');

      //We are assuming exact match if the key as swapped as this is typically a multi-select scenario
      let exact = false;
      if (keySwaps[field]) {
        field = keySwaps[field];
        exact = true;
      }
      const value = params.getAll(key).filter((v) => !!v);
      if (value) {
        if (exact) {
          data = data.filter((item) => {
            return value.includes(item[field]);
          });
        } else {
          data = data.filter((item) => {
            return value.some((v) => item[field]?.includes(v));
          });
        }
      }
    } else if (key.startsWith('filter.') && key.endsWith('.operator')) {
      const filterKey = key.replace('.operator', '').replace('filter.', '');
      const keySwaps = filterKeySwaps[modelName] || {};
      const fieldKey = keySwaps[filterKey] || filterKey;

      const operator = params.get(key);
      const filterValue = parseRelativeDate(
        params.get(`filter.${filterKey}.relative_to_now`),
      );

      if (operator && filterValue) {
        data = data.filter((item) => {
          const itemValue = new Date(item[fieldKey]);
          switch (operator) {
            case 'GREATER_THAN':
              return itemValue > filterValue;
            case 'GREATER_THAN_OR_EQUAL':
              return itemValue >= filterValue;
            case 'LESS_THAN':
              return itemValue < filterValue;
            case 'LESS_THAN_OR_EQUAL':
              return itemValue <= filterValue;
            default:
              console.warn('unknown operator', operator);
              return false;
          }
        });
      }
    }
  });

  // stored_in_vault boolean should only filter if set and should not do anything for empty value
  const stored_in_vault = params.get('filter.stored_in_vault');
  if (stored_in_vault === 'true') {
    data = data.filter((item) => item.stored_in_vault === true);
  } else if (stored_in_vault === 'false') {
    data = data.filter((item) => item.stored_in_vault === false);
  }

  // filter out any deleted secrets unless include_deleted is true
  const includeDeleted = params.get('filter.include_deleted') === 'true';
  if (!includeDeleted) {
    data = data.filter((item) => !item.secret_deleted_at);
  }

  if (params.has('sorting.order_by')) {
    const orderBy = params.get('sorting.order_by');
    const [field, direction] = orderBy.split(' ');

    data = data.sort((a, b) => {
      if (direction === 'asc') {
        return a[field] > b[field] ? 1 : -1;
      } else {
        return a[field] < b[field] ? 1 : -1;
      }
    });
  }
  return { data };
}

export function getInventory(schema, request) {
  const url = new URL(request.url);
  const params = url.searchParams;
  const reportType = request.params.reportType;
  const clusterId = request.params.clusterId;

  if (!reportTypePathParamToModel[reportType]) {
    throw new Error(`Invalid report type: ${reportType}`);
  }
  const modelName = reportTypePathParamToModel[reportType];
  const { data } = getFilteredRecords.call(this, modelName, schema, request);
  const pageSize = parseInt(params.get('pagination.page_size'), 10) || 10;
  const nextPageToken = parseInt(params.get('pagination.next_page_token'), 10);
  const previousPageToken = parseInt(
    params.get('pagination.previous_page_token'),
    10,
  );

  // Apply pagination
  if (isNaN(pageSize) || pageSize <= 0) {
    throw new Error(`Invalid page size: ${pageSize}`);
  }
  if (nextPageToken < 0 || previousPageToken < 0) {
    throw new Error(
      `Invalid page tokens: nextPageToken=${nextPageToken}, previousPageToken=${previousPageToken}`,
    );
  }

  let startIndex;
  let pageData = data;

  if (nextPageToken) {
    startIndex = nextPageToken;
  } else if (previousPageToken) {
    startIndex = previousPageToken - pageSize - 1;
  } else {
    startIndex = 0;
  }

  pageData = data.slice(startIndex, startIndex + pageSize);

  return {
    data: pageData,
    report_as_of:
      pageData.length > 0 ? new Date().toISOString() : '0001-01-01T00:00:00Z',
    last_scan_completed_at: clusterId.startsWith('scanned-')
      ? faker.date.past().toISOString()
      : undefined,
    pagination: {
      next_page_token:
        startIndex + pageSize < data.length
          ? String(startIndex + pageSize)
          : null,
      previous_page_token: startIndex > 0 ? String(startIndex + 1) : null,
    },
  };
}

export function getInventoryCount(schema, request) {
  const reportType = request.params.reportType;

  if (!reportTypePathParamToModel[reportType]) {
    throw new Error(`Invalid report type: ${reportType}`);
  }
  const modelName = reportTypePathParamToModel[reportType];
  const { data } = getFilteredRecords.call(this, modelName, schema, request);
  return {
    count: data.length,
  };
}

function getDistinctFields(
  modelName,
  schema,
  request,
  search,
  fieldKey,
  responseKey,
  collectionKey,
) {
  const data = getAllRecords.call(this, modelName, schema, request);

  let fields = data.map((item) => item[fieldKey]);
  if (search) {
    fields = fields.filter((item) => item.includes(search.trim()));
  }
  // Return first 10 results to approximate getting pagination and only getting the first page of data
  const uniqueFields = Array.from(new Set(fields)).slice(0, 10);

  return {
    [collectionKey || `${fieldKey}s`]: uniqueFields.map((field) => {
      if (responseKey) {
        return { [responseKey]: field };
      }
      return field;
    }),
  };
}

export function getDistinctNamespaces(schema, request) {
  const url = new URL(request.url);
  const params = url.searchParams;
  const namespacePathPrefix = params.get('namespace_path_prefix');
  const reportType = params.get('report_type');
  const model = reportTypeQueryParamToModel[reportType];

  if (!model) {
    throw new Error(`Invalid report type: ${reportType}`);
  }
  return getDistinctFields.call(
    this,
    model,
    schema,
    request,
    namespacePathPrefix,
    'namespace',
    'path',
    'namespaces',
  );
}

export function getDistinctMounts(schema, request) {
  const url = new URL(request.url);
  const params = url.searchParams;
  const mountPathPrefix = params.get('mount_path_prefix');
  const reportType = params.get('report_type');
  const model = reportTypeQueryParamToModel[reportType];

  if (!model) {
    throw new Error(`Invalid report type: ${reportType}`);
  }
  return getDistinctFields.call(
    this,
    model,
    schema,
    request,
    mountPathPrefix,
    'mount_path',
    'mount_path',
    'mounts',
  );
}

export function getDistinctEntityIds(schema, request) {
  const url = new URL(request.url);
  const params = url.searchParams;
  let column = params.get('column').toLowerCase();
  let model = 'vaultReporting.secrets';
  if (column.startsWith('certificate_')) {
    model = 'vaultReporting.certificates';
    column = column.replace('certificate_', '');
  }

  return getDistinctFields.call(
    this,
    model,
    schema,
    request,
    '',
    column,
    undefined,
    'ids',
  );
}

export function getDistinctCertificateKeyAlgorithms(schema, request) {
  const url = new URL(request.url);
  const params = url.searchParams;
  const search = params.get('key_algorithm_prefix');
  const model = reportTypeQueryParamToModel['REPORT_TYPE_CERTIFICATES'];

  return getDistinctFields.call(
    this,
    model,
    schema,
    request,
    search,
    'key_algorithm',
    undefined,
    'key_algorithms',
  );
}

export function getDistinctCertificateKeyTypes(schema, request) {
  const url = new URL(request.url);
  const params = url.searchParams;
  const search = params.get('key_type_prefix');
  const model = reportTypeQueryParamToModel['REPORT_TYPE_CERTIFICATES'];

  return getDistinctFields.call(
    this,
    model,
    schema,
    request,
    search,
    'key_type',
    undefined,
    'key_types',
  );
}
