/**
 * Copyright IBM Corp. 2025
 * SPDX-License-Identifier: BUSL-1.1
 */

import serializers from './serializers';
import factories from './factories';
import models from './models';
import * as vaultReportingHandlers from './handlers';

function routes() {
  // Inventory (Secrets and Certificates)
  this.get(
    '/vault-reporting/:date/organizations/:orgId/projects/:projectId/clusters/:clusterId/reports/:reportType',
    vaultReportingHandlers.getInventory,
  );
  this.get(
    '/vault-reporting/:date/organizations/:orgId/projects/:projectId/clusters/:clusterId/reports/:reportType/count',
    vaultReportingHandlers.getInventoryCount,
  );
  this.get(
    '/vault-reporting/:date/organizations/:orgId/projects/:projectId/clusters/:clusterId/reports/distinct-namespaces',
    vaultReportingHandlers.getDistinctNamespaces,
  );
  this.get(
    '/vault-reporting/:date/organizations/:orgId/projects/:projectId/clusters/:clusterId/reports/distinct-mounts',
    vaultReportingHandlers.getDistinctMounts,
  );

  this.get(
    '/vault-reporting/:date/organizations/:orgId/projects/:projectId/clusters/:clusterId/reports/distinct-entity-ids',
    vaultReportingHandlers.getDistinctEntityIds,
  );

  this.get(
    '/vault-reporting/:date/organizations/:orgId/projects/:projectId/clusters/:clusterId/reports/distinct-certificate-key-algorithms',
    vaultReportingHandlers.getDistinctCertificateKeyAlgorithms,
  );

  this.get(
    '/vault-reporting/:date/organizations/:orgId/projects/:projectId/clusters/:clusterId/reports/distinct-certificate-key-types',
    vaultReportingHandlers.getDistinctCertificateKeyTypes,
  );

  // Saved Views
  // Create
  this.post(
    '/vault-reporting/:date/organizations/:orgId/projects/:projectId/clusters/:clusterId/reports/:reportType/dashboards/:dashboardSlug/saved-views',
    vaultReportingHandlers.createSavedView,
  );
  // Delete
  this.del(
    '/vault-reporting/:date/organizations/:orgId/projects/:projectId/clusters/:clusterId/reports/:reportType/dashboards/:dashboardSlug/saved-views/:id',
    vaultReportingHandlers.deleteSavedView,
  );
  // List
  this.get(
    '/vault-reporting/:date/organizations/:orgId/projects/:projectId/clusters/:clusterId/reports/:reportType/dashboards/:dashboardSlug/saved-views',
    vaultReportingHandlers.listSavedViews,
  );
  // Update
  this.put(
    '/vault-reporting/:date/organizations/:orgId/projects/:projectId/clusters/:clusterId/reports/:reportType/dashboards/:dashboardSlug/saved-views/:id',
    vaultReportingHandlers.updateSavedView,
  );
  // Reorder
  this.put(
    '/vault-reporting/:date/organizations/:orgId/projects/:projectId/clusters/:clusterId/reports/:reportType/dashboards/:dashboardSlug/saved-views:reorder',
    vaultReportingHandlers.reorderSavedViews,
  );
}

export default {
  routes,
  serializers,
  factories,
  models,
};
