/**
 * Copyright IBM Corp. 2025
 * SPDX-License-Identifier: BUSL-1.1
 */

import vaultReportingDefault from './default.js';
import vaultReportingSavedView from './saved-view.js';

export default {
  'vaultReporting.secret': vaultReportingDefault,
  'vaultReporting.savedView': vaultReportingSavedView,
  'vaultReporting.certificate': vaultReportingDefault,
};
