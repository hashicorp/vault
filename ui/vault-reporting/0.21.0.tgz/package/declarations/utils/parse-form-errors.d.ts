import type { ResponseError } from '../clients/cloud-vault-reporting/src';
export interface FormErrors {
    form: string[];
    fields: {
        [field: string]: string[];
    };
}
export declare const parseFormErrors: (error: ResponseError, fieldKeys?: string[]) => Promise<FormErrors>;
