/**
 * Copyright IBM Corp. 2025
 * SPDX-License-Identifier: BUSL-1.1
 */
import type { FilterFieldDefinition, FilterFieldName } from '../components/vault-reporting/filter-bar';
export interface Filter<T = Record<string, unknown>> {
    field: Extract<keyof FilterFieldName<T>, string>;
    operator: '>' | '<' | '=';
    value: {
        type: 'string' | 'date' | 'duration' | 'list' | 'boolean';
        value: string | number | string[] | boolean;
    };
}
type FilterMap = {
    [key: string]: string | number | Date | string[];
};
export declare const filtersToFilterRequest: (filters?: Filter[]) => Record<string, unknown>;
export declare const flatten: (obj: Record<string, unknown>, prefix?: string) => Record<string, unknown>;
export declare const flattenFilters: (filterList?: Filter[]) => Record<string, unknown>;
/**
 * Converts flattened API request parameters back into Filter array format using FilterFieldDefinitions.
 * This is the reverse operation of flattenFilters and uses the field definitions as source of truth.
 * @param flattenedParams The flattened parameters object
 * @param filterFieldDefinitions The filter field definitions that define the structure and options
 * @returns Array of Filter objects for UI state
 */
export declare const unflattenFiltersWithDefinitions: <T = FilterMap>(flattenedParams: T, filterFieldDefinitions: FilterFieldDefinition<T>[]) => Filter[];
/**
 * Formats an applied filter for display.
 * @param filter The filter to format.
 * @param label An optional label to use instead of the filter's field name.
 * @returns An array of formatted filter tags.
 *
 * Handles different value types:
 * - Boolean: Displays the label if true, nothing if false.
 * - Duration: Converts hours to a human-readable format (e.g., "30 days ago").
 * - String/List: Displays each value with the appropriate operator.
 */
export declare const formatAppliedFilter: (filter: Filter, fieldDefinition?: FilterFieldDefinition) => {
    label: string;
    field: string;
    value: string;
}[];
/**
 * Generates lookback filter options for a given array of days.
 * @param days Array of days to generate lookback options for. Defaults to [-7, -30, -60, -90].
 * @param operator The comparison operator to use. Defaults to '<'.
 * @param labelPrefix Optional prefix for the label (e.g., 'Past' for 'Past 7 days').
 * @returns Array of lookback filter options with name and value properties.
 *
 * Each option's name is formatted as "X days ago" for negative values and "X days" for positive values,
 * unless a labelPrefix is provided (e.g., "Past X days").
 * The value is formatted as a duration string in seconds (e.g., "<-604800s" for -7 days).
 */
export declare const getLookbackFilterOptions: (days?: number[], operator?: string, labelPrefix?: string) => {
    name: string;
    value: string;
}[];
/**
 * Compares two filter arrays to determine if they are equivalent.
 * Filters are considered equal if they contain the same field, operator, and value,
 * regardless of the order in which they appear in the arrays.
 *
 * @param filters1 First array of filters to compare
 * @param filters2 Second array of filters to compare
 * @returns true if the filter arrays are equivalent, false otherwise
 */
export declare const areFiltersEqual: (filters1: Filter[], filters2: Filter[]) => boolean;
declare const filters: {
    flattenFilters: (filterList?: Filter[]) => Record<string, unknown>;
    areFiltersEqual: (filters1: Filter[], filters2: Filter[]) => boolean;
};
export default filters;
