/**
 * Copyright IBM Corp. 2025
 * SPDX-License-Identifier: BUSL-1.1
 */
export declare const filenameDate: (date?: Date) => string;
/**
 * Converts a number of days to a gRPC duration string format
 * @param days - The number of days to convert
 * @returns A duration string in seconds format (e.g., "259200s" for 3 days)
 */
export declare const daysToGrpcDuration: (days: number) => string;
/**
 * Formats a duration string from seconds format to human-readable format
 * @param duration - A duration string in seconds format (e.g., "3600s") or null
 * @returns A human-readable duration string (e.g., "1 hour") or empty string if null/invalid
 */
export declare const formatDuration: (duration: string | null) => string;
declare const dateTimeUtils: {
    daysToGrpcDuration: (days: number) => string;
    formatDuration: (duration: string | null) => string;
};
export default dateTimeUtils;
