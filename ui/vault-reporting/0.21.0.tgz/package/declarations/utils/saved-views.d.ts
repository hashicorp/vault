import type { SavedView } from '../components/vault-reporting/saved-views/card';
export declare const getSavedViewAnalyticsParams: (newSavedView: SavedView, oldSavedView?: SavedView) => Record<string, unknown>;
