/**
 * Copyright IBM Corp. 2025
 * SPDX-License-Identifier: BUSL-1.1
 */
/**
 * Compares two arrays of column keys to determine if they are equal.
 * Returns true if both arrays have the same length and contain the same keys in the same order.
 *
 * @param columns1 - First array of column keys
 * @param columns2 - Second array of column keys
 * @returns true if the column arrays are equal, false otherwise
 */
export declare function areColumnsEqual(columns1: string[], columns2: string[]): boolean;
/**
 * Compares two sorting arrays to determine if they are equal.
 * These arrays are either empty or contain a single element.
 *
 * @param sort1 - First sorting array
 * @param sort2 - Second sorting array
 * @returns true if the sorting is equal, false otherwise
 */
export declare function areSortingOrdersEqual(sort1: string[], sort2: string[]): boolean;
declare const _default: {
    areColumnsEqual: typeof areColumnsEqual;
    areSortingOrdersEqual: typeof areSortingOrdersEqual;
};
export default _default;
