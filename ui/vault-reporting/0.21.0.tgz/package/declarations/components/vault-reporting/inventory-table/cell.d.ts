import Component from '@glimmer/component';
import type { TOC } from '@ember/component/template-only';
import type { InventoryTableColumn } from '../inventory-table';
export interface CellRendererBaseSignature {
    Args: {
        rawValue?: string;
        row?: Record<string, unknown>;
        column?: InventoryTableColumn;
    };
    Blocks: {
        default: [];
    };
    Element: HTMLElement;
}
export declare const CellRendererDefault: TOC<CellRendererBaseSignature>;
export declare const CellRendererBoolean: TOC<CellRendererBaseSignature>;
export declare const CellRendererDateTime: TOC<CellRendererBaseSignature>;
export declare const CellRendererDateTimeRelative: TOC<CellRendererBaseSignature>;
export declare const CellRendererBadge: TOC<CellRendererBaseSignature>;
export interface InventoryTableCellSignature {
    Args: {
        row?: Record<string, unknown>;
        column: InventoryTableColumn;
    };
    Blocks: {
        default: [];
    };
    Element: HTMLElement;
}
export default class InventoryTableCell extends Component<InventoryTableCellSignature> {
    get components(): {
        component: TOC<CellRendererBaseSignature>;
        rawValue: string;
        row: Record<string, unknown> | undefined;
        column: InventoryTableColumn;
        class: string;
    }[];
}
