import type { TOC } from '@ember/component/template-only';
import type { CellRendererBaseSignature } from '../cell.ts';
declare const CellRendererCertificateStatusBadge: TOC<CellRendererBaseSignature>;
export default CellRendererCertificateStatusBadge;
