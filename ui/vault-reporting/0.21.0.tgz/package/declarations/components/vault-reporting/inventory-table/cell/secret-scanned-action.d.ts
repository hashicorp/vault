import type { CellRendererBaseSignature } from '../cell.ts';
import type { TOC } from '@ember/component/template-only';
declare const CellRendererSecretScannedAction: TOC<CellRendererBaseSignature>;
export default CellRendererSecretScannedAction;
