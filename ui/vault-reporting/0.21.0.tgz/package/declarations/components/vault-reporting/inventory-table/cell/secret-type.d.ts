import type { TOC } from '@ember/component/template-only';
import type { CellRendererBaseSignature } from '../cell.ts';
import { FetchSecretsInventoryFilterSecretTypesEnum as SecretTypesEnum } from '../../../../clients/cloud-vault-reporting/src/index.ts';
export declare const SECRET_TYPE_OPTIONS: {
    name: string;
    value: SecretTypesEnum;
}[];
declare const CellRendererSecretType: TOC<CellRendererBaseSignature>;
export default CellRendererSecretType;
