import type { TOC } from '@ember/component/template-only';
import type { CellRendererBaseSignature } from '../cell.ts';
declare const CellRendererSecretRenewalPolicy: TOC<CellRendererBaseSignature>;
export default CellRendererSecretRenewalPolicy;
