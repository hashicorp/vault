import type { TOC } from '@ember/component/template-only';
import type { CellRendererBaseSignature } from '../cell.ts';
import { FetchCertificatesInventoryFilterCertificateTypesEnum as CertificateType } from '../../../../clients/cloud-vault-reporting/src/index.ts';
export declare const CERTIFICATE_TYPE_OPTIONS: {
    value: CertificateType;
    name: string;
}[];
declare const CellRendererCertificateType: TOC<CellRendererBaseSignature>;
export default CellRendererCertificateType;
