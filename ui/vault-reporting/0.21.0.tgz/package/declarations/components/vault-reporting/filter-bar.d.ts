/**
 * Copyright IBM Corp. 2025
 * SPDX-License-Identifier: BUSL-1.1
 */
import Component from '@glimmer/component';
import { type Filter } from '../../utils/filters.ts';
import type { SavedView } from './saved-views/card';
import './filter-bar.scss';
import type Owner from '@ember/owner';
import type RouterService from '@ember/routing/router-service';
import { type IntlService } from 'ember-intl';
type StripFilterPrefix<S extends string> = S extends `filter${infer Rest}` ? Rest extends `${infer First}${infer Tail}` ? Tail extends `${infer Middle}Absolute` ? `${Lowercase<First>}${Middle}` : `${Lowercase<First>}${Tail}` : Rest : S;
export type FilterFieldName<T> = {
    [K in keyof T as StripFilterPrefix<K & string>]: K;
};
export type FilterFieldControlOption = {
    name: string;
    value: string;
};
export interface FilterFieldControl<T = Record<string, unknown>> {
    name: Extract<keyof FilterFieldName<T>, string>;
    label: string;
    type: 'text' | 'boolean' | 'single-select' | 'multi-select' | 'lookback' | 'search' | 'searchable-multi-select';
    dependsOn?: (form: Record<string, Filter>) => boolean;
    placeholder?: string;
    options?: FilterFieldControlOption[];
    onSearch?: (search: string) => Promise<FilterFieldControlOption[]>;
}
export interface FilterFieldDefinition<T = Record<string, unknown>> {
    name: Extract<keyof FilterFieldName<T>, string>;
    label: string;
    level?: 'primary' | 'secondary';
    controls: FilterFieldControl<T>[];
}
export interface FilterBarSignature {
    Args: {
        onFiltersApplied: (filters: Filter[]) => void;
        appliedFilters?: Filter[];
        appliedSort?: string[];
        filterFieldDefinitions: FilterFieldDefinition[];
        columns?: {
            label: string;
            key: string;
            visible?: boolean;
            alwaysVisible?: boolean;
        }[];
        onColumnsChanged?: (visibleColumnKeys: string[]) => void;
        onColumnsReset?: () => void;
        onOpenCreateSavedView?: () => void;
        onOpenUpdateSavedView?: () => void;
        activeSavedView?: SavedView | null;
        editableSavedViews?: boolean;
        defaultVisibleColumnKeys?: string[];
    };
    Blocks: {
        default: [];
    };
    Element: HTMLElement;
}
export default class FilterBar extends Component<FilterBarSignature> {
    readonly router: RouterService;
    readonly intl: IntlService;
    activeSecondaryFilter: FilterFieldDefinition | null;
    pendingColumnVisibility: Record<string, boolean>;
    defaultRouteQueryParams: {
        filters: never[];
        visibleColumns: string[];
        sortingOrderBy: never[];
        savedViewId: string;
    };
    constructor(owner: Owner, args: FilterBarSignature['Args']);
    handleOpenCreateSavedView: () => void;
    handleOpenUpdateSavedView: () => void;
    setActiveSecondaryFilter: (filter: FilterFieldDefinition | null) => void;
    handleUpdateFilters: (filters: Record<string, Filter>) => void;
    handleDismissFilter: (field: string, value: string | boolean | number) => void;
    handleColumnToggle: (columnKey: string, event: Event) => void;
    handleApplyColumns: () => void;
    handleResetColumns: () => void;
    handleFieldsDropdownClose: () => void;
    getColumnVisibility: (columnKey: string) => boolean | undefined;
    get hasPendingColumnChanges(): boolean;
    get visibleColumnsCount(): number | undefined;
    handleTextInputChange: (name: string, event: Event) => void;
    getValue: (name: string) => string;
    getCount: (name: string) => number;
    hasCount: (name: string) => boolean;
    getDefinitionCount: (filter: FilterFieldDefinition) => number;
    hasDefinitionCount: (filter: FilterFieldDefinition) => boolean;
    get appliedFilters(): Record<string, Filter<Record<string, unknown>>>;
    get appliedFilterTags(): {
        label: string;
        field: string;
        value: string;
    }[];
    get appliedFiltersCount(): number;
    get hasAppliedFilters(): boolean;
    get currentVisibleColumnKeys(): string[];
    get hasChangesFromDefault(): boolean;
    get hasChangesFromSavedView(): boolean;
    get primaryFilterDefinitions(): FilterFieldDefinition<Record<string, unknown>>[];
    get secondaryFilterDefinitions(): FilterFieldDefinition<Record<string, unknown>>[];
    get appliedSecondaryFiltersCount(): number;
}
export {};
