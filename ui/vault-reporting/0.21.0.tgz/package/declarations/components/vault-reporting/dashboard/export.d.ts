/**
 * Copyright IBM Corp. 2025
 * SPDX-License-Identifier: BUSL-1.1
 */
import Component from '@glimmer/component';
import type { UsageDashboardData } from '../../../types';
import type ReportingAnalyticsService from '../../../services/reporting-analytics';
import { type IntlService } from 'ember-intl';
export interface DashboardExportSignature {
    Args: {
        data?: UsageDashboardData;
    };
    Blocks: {
        default: [];
    };
    Element: HTMLElement;
}
export default class DashboardExport extends Component<DashboardExportSignature> {
    #private;
    readonly reportingAnalytics: ReportingAnalyticsService;
    readonly intl: IntlService;
    handleTrackExportToggle: () => void;
    handleTrackExportOption: (option: string) => void;
    get dataAsDownloadableJSONString(): string;
    get dataAsDownloadableCSVString(): string;
}
