/**
 * Copyright IBM Corp. 2025
 * SPDX-License-Identifier: BUSL-1.1
 */
import './inventory.scss';
import Component from '@glimmer/component';
import { type Filter } from '../../../utils/filters.ts';
import { type InventoryTableColumn } from '../inventory-table';
import { type IntlService } from 'ember-intl';
import type ReportingApiService from '../../../services/reporting-api.ts';
import type RouterService from '@ember/routing/router-service';
import type ReportingAnalyticsService from '../../../services/reporting-analytics';
import type { InventoryViewDefinition } from '../../../constants/view-definitions.ts';
import { type SavedView as QuickFilter } from '../saved-views/card';
import type ReportingNotificationsService from '../../../services/reporting-notifications.ts';
import type Owner from '@ember/owner';
import type { FilterFieldDefinition } from '../filter-bar.ts';
export interface InventorySignature {
    Args: {
        viewDefinition: InventoryViewDefinition;
        onFilterApplied: (value: Filter[]) => void;
        onSortApplied: (sort: string[]) => void;
        appliedFilters: Filter[];
        appliedSort: string[];
        onPageChange: (pagination: {
            next_page_token?: string;
            previous_page_token?: string;
            page_size: number;
        }) => void;
        pageSize: number;
        nextPageToken?: string;
        previousPageToken?: string;
        activeCluster: string;
        visibleColumns?: string[];
        onColumnsChanged?: (visibleColumns: string[]) => void;
        editableSavedViews?: boolean;
        activeSavedViewId?: string;
        isOverridingContent?: boolean;
    };
    Blocks: {
        actions: [];
        overrideContent: [];
        tableContextPanel: [];
    };
    Element: HTMLElement;
}
export default class Inventory extends Component<InventorySignature> {
    readonly reportingApi: ReportingApiService;
    readonly reportingAnalytics: ReportingAnalyticsService;
    readonly reportingNotifications: ReportingNotificationsService;
    readonly router: RouterService;
    readonly intl: IntlService;
    page: Record<string, unknown>[];
    isLoading: boolean;
    isError: boolean;
    isEmpty: boolean;
    nextPageToken?: string;
    previousPageToken?: string;
    pageSize: number;
    totalUnfilteredCount: number;
    isDownloadModalOpen: boolean;
    isCreateSavedViewModalOpen: boolean;
    lastUpdatedTime?: Date;
    quickFilters: QuickFilter[];
    lastScanCompletedAt?: Date;
    columns: InventoryTableColumn[];
    filters: FilterFieldDefinition[];
    title: string;
    descriptionName: string;
    downloadFileName: string;
    lastRequest?: Record<string, unknown>;
    constructor(owner: Owner, args: InventorySignature['Args']);
    localizeColumns: () => {
        label: string;
        tooltip: string | undefined;
        width?: string | undefined;
        align?: import("@hashicorp/design-system-components/components").HdsAdvancedTableHorizontalAlignment | undefined;
        component?: import("@ember/component/template-only").TOC<import("../inventory-table/cell.ts").CellRendererBaseSignature> | undefined;
        key: string;
        secondaryKey?: string | undefined;
        secondaryComponent?: import("@ember/component/template-only").TOC<import("../inventory-table/cell.ts").CellRendererBaseSignature> | undefined;
        isSortable?: boolean | undefined;
        isVisuallyHidden?: boolean | undefined;
        sortingFunction?: import("@hashicorp/design-system-components/components").HdsAdvancedTableSortingFunction<unknown> | undefined;
        minWidth?: `${number}px` | undefined;
        maxWidth?: `${number}px` | undefined;
        alwaysVisible?: boolean | undefined;
        renderCondition?: ((data: Record<string, unknown>) => boolean) | undefined;
    }[];
    get isExportButtonDisabled(): boolean | undefined;
    get visibleColumns(): InventoryTableColumn[];
    get visibleColumnKeys(): string[];
    get filterDefinitions(): {
        controls: import("../filter-bar.ts").FilterFieldControl<Record<string, unknown>>[];
        name: string;
        label: string;
        level?: "primary" | "secondary";
    }[];
    handlePageSizeChange: (newPageSize: number) => void;
    fetchSavedViews: () => Promise<void>;
    handleColumnsChanged: (visibleColumnKeys: string[]) => void;
    handleColumnsReset: () => void;
    get activeSavedView(): QuickFilter | null;
    get defaultVisibleColumnKeys(): string[];
    fetchQuickFilterCount: (filter: QuickFilter) => Promise<QuickFilter>;
    fetchQuickFilterCounts: () => Promise<void>;
    handleDataUpdate: (filters: Filter[]) => Promise<void>;
    handleDownload: () => Promise<Record<string, unknown>[]>;
    handleFileDownloaded: (format: string) => void;
    handleDeleteSavedView: (savedView: QuickFilter) => Promise<void>;
    handleUpdateSavedView: (savedView: QuickFilter, value: {
        name: string;
        description: string;
    }, mode: "create" | "rename" | "full-update") => Promise<void>;
    handleReorderSavedViews: (newOrder: string[]) => Promise<void>;
    openCreateSavedViewModal: () => void;
    closeCreateSavedViewModal: () => void;
    handleCreateSavedView: ({ name, description, }: {
        name: string;
        description: string;
    }) => Promise<void>;
    refreshSavedViewsAndCounts: () => Promise<void>;
    closeDownloadModal: () => void;
    openDownloadModal: () => void;
}
