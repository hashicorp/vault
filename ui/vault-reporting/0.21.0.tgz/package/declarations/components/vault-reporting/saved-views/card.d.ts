import type { TOC } from '@ember/component/template-only';
import type { Filter } from '../../../utils/filters';
export type SavedView = {
    label: string;
    description?: string;
    id: string;
    linkParams: {
        filters?: Filter[];
        visibleColumns?: string[];
        sortingOrderBy?: string[];
        savedViewId?: string;
    };
    count?: number;
};
interface SavedViewCardSignature {
    Element: HTMLElement;
    Args: {
        savedView: SavedView;
        totalUnfilteredCount: number;
        routeName: string;
        isEditable?: boolean;
        isReordering?: boolean;
        isActive?: boolean;
        onLinkClick: (savedView: SavedView) => void;
        onDeleteClick: (savedView: SavedView) => void;
        onRenameClick: (savedView: SavedView) => void;
        onReorderClick: (savedView: SavedView) => void;
    };
    Blocks: {
        actions: [];
    };
}
export declare const SavedViewCard: TOC<SavedViewCardSignature>;
export default SavedViewCard;
