import Component from '@glimmer/component';
import { type IntlService } from 'ember-intl';
import { type SavedView } from './card';
import type RouterService from '@ember/routing/router-service';
import type ReportingAnalytics from '../../../services/reporting-analytics';
import type ReportingApiService from '../../../services/reporting-api';
interface SavedViewListSignature {
    Args: {
        analyticsPrefix?: string;
        activeSavedViewId?: string;
        isEditable?: boolean;
        totalUnfilteredCount: number;
        savedViews: SavedView[];
        onDeleteSavedView?: (savedView: SavedView) => void;
        onUpdateSavedView?: (savedView: SavedView) => void;
        onReorderSavedViews?: (newOrder: string[]) => Promise<void>;
        descriptionName?: string;
    };
    Blocks: {
        default: [];
    };
}
export default class SavedViewList extends Component<SavedViewListSignature> {
    readonly router: RouterService;
    readonly reportingAnalytics: ReportingAnalytics;
    readonly reportingApi: ReportingApiService;
    readonly intl: IntlService;
    selectedSavedView?: SavedView;
    isDeletingSavedView: boolean;
    isReordering: boolean;
    isSavingNewOrder: boolean;
    activeDraggedSavedView?: SavedView;
    stagedOrder: SavedView[];
    pendingOrder: SavedView[];
    screenReaderText: string;
    get routeName(): string;
    get description(): string;
    trackAnalyticsEvent: (eventName: string, properties: Record<string, unknown>) => void;
    handleSavedViewDeleteClick: (savedView: SavedView) => void;
    handleSavedViewLinkClick: (savedView: SavedView) => void;
    handleSavedViewRenameClick: (savedView: SavedView) => void;
    handleSavedViewReorderClick: () => void;
    getItemClasses: (savedView: SavedView) => string;
    get orderedSavedViews(): SavedView[];
    isGrabbed: (savedView: SavedView) => boolean;
    getDropEffect: (savedView: SavedView) => "move" | "none" | undefined;
    handleDragStart: (item: SavedView) => void;
    handleDragEnd: () => void;
    selectItem: (item: SavedView) => void;
    deselectItem: () => void;
    handleDragOver: (item: SavedView, event: DragEvent) => void;
    moveActiveItem: (places: number) => void;
    handleKeyDown: (item: SavedView, event: KeyboardEvent) => void;
    handleSaveNewOrder: () => Promise<void>;
    handleCancelReorder: () => void;
    getItemAriaLabel: (savedView: SavedView) => string;
}
export {};
