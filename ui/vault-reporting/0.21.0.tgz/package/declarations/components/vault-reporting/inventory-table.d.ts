/**
 * Copyright IBM Corp. 2025
 * SPDX-License-Identifier: BUSL-1.1
 */
import { type HdsAdvancedTableColumn } from '@hashicorp/design-system-components/components';
import { type FilterFieldDefinition } from './filter-bar';
import './inventory-table.scss';
import Component from '@glimmer/component';
import { type Filter } from '../../utils/filters.ts';
import type ReportingAnalytics from '../../services/reporting-analytics.ts';
import { type CellRendererBaseSignature } from './inventory-table/cell';
import type { TOC } from '@ember/component/template-only';
import { type SavedView } from './saved-views/card';
interface InventoryTableColumnConfig<T = Record<string, unknown>> {
    key: Extract<keyof T, string>;
    alwaysVisible?: boolean;
    secondaryKey?: string;
    component?: TOC<CellRendererBaseSignature>;
    secondaryComponent?: TOC<CellRendererBaseSignature>;
    renderCondition?: (data: Record<string, unknown>) => boolean;
}
export type InventoryTableColumn<T = Record<string, unknown>> = HdsAdvancedTableColumn & InventoryTableColumnConfig<T>;
export interface InventoryTableSignature {
    Args: {
        onFilterApplied: (value: Filter[]) => void;
        onSortApplied: (sort: string[]) => void;
        onPageChange: (pagination: {
            next_page_token?: string;
            previous_page_token?: string;
            page_size: number;
        }) => void;
        onPageSizeChange?: (pageSize: number) => void;
        onColumnsChanged?: (visibleColumnKeys: string[]) => void;
        onColumnsReset?: () => void;
        rowClassAccessor?: (row?: Record<string, unknown>) => string;
        visibleColumns: InventoryTableColumn[];
        pageSize?: number;
        nextPageToken?: string;
        previousPageToken?: string;
        appliedFilters: Filter[];
        appliedSort: string[];
        filterFieldDefinitions: FilterFieldDefinition[];
        columns: InventoryTableColumn[];
        rows: Record<string, unknown>[];
        quickFilters: SavedView[];
        isLoading?: boolean;
        isError?: boolean;
        isEmpty?: boolean;
        totalUnfilteredCount: number;
        analyticsPrefix?: string;
        editableSavedViews?: boolean;
        activeSavedViewId?: string;
        descriptionName?: string;
        activeSavedView?: SavedView | null;
        onOpenCreateSavedView?: () => void;
        onDeleteSavedView?: (savedView: SavedView) => Promise<void>;
        onUpdateSavedView?: (savedView: SavedView, value: {
            name: string;
            description: string;
        }, mode: 'create' | 'rename' | 'full-update') => Promise<void>;
        onReorderSavedViews?: (newOrder: string[]) => Promise<void>;
        defaultVisibleColumnKeys?: string[];
    };
    Blocks: {
        default: [];
        tableContextPanel: [];
        filterBarContextPanel: [];
    };
    Element: HTMLElement;
}
export default class InventoryTable extends Component<InventoryTableSignature> {
    readonly reportingAnalytics: ReportingAnalytics;
    isUpdateSavedViewModalOpen: boolean;
    selectedSavedView?: SavedView;
    updateModalMode: 'create' | 'rename' | 'full-update';
    isDeleteSavedViewModalOpen: boolean;
    isDeletingSavedView: boolean;
    openDeleteSavedViewModal: (savedView: SavedView) => void;
    closeDeleteSavedViewModal: () => void;
    deleteSelectedSavedView: () => Promise<void>;
    openUpdateSavedViewModal: (mode: "create" | "rename" | "full-update", savedView?: SavedView) => void;
    openUpdateSavedViewModalForRenaming: (savedView: SavedView) => void;
    openUpdateSavedViewModalForFullUpdate: () => void;
    closeUpdateSavedViewModal: () => void;
    updateSelectedSavedView: (value: {
        name: string;
        description: string;
    }) => Promise<void>;
    trackAnalyticsEvent: (eventName: string, properties: Record<string, unknown>) => void;
    handleApplyFilters: (filters: Filter[]) => void;
    handleSort: (sortBy: string, sortOrder: "asc" | "desc") => void;
    handlePageChange: (direction: string) => void;
    handlePageSizeChange: (pageSize: number) => void;
    handleColumnsChanged: (visibleColumnKeys: string[]) => void;
    get isDisabledNext(): boolean | undefined;
    get isDisabledPrev(): boolean | undefined;
    getCellContent: (row: Record<string, unknown> | undefined, key: string, formatter?: (data: Record<string, unknown>) => string) => string;
    getRowClass: (row?: Record<string, unknown>) => string;
    get sortBy(): {
        key: string;
        order: "asc" | "desc";
    };
    get rows(): Record<string, unknown>[];
    get hasMessage(): boolean | undefined;
    get visibleColumnKeys(): string[];
    get columnsForFilterBar(): {
        label: string;
        key: string;
        visible: boolean;
        alwaysVisible: boolean | undefined;
    }[];
    get columnsWithUpdatedWidths(): ({
        width: string;
        isSortable: true;
        key: string;
        align?: import("@hashicorp/design-system-components/components").HdsAdvancedTableHorizontalAlignment;
        isVisuallyHidden?: boolean;
        label: string;
        sortingFunction?: import("@hashicorp/design-system-components/components").HdsAdvancedTableSortingFunction<unknown>;
        tooltip?: string;
        minWidth?: `${number}px`;
        maxWidth?: `${number}px`;
        alwaysVisible?: boolean;
        secondaryKey?: string;
        component?: TOC<CellRendererBaseSignature>;
        secondaryComponent?: TOC<CellRendererBaseSignature>;
        renderCondition?: (data: Record<string, unknown>) => boolean;
    } | {
        width: string;
        isSortable?: false;
        key: string;
        isExpandable?: boolean;
        align?: import("@hashicorp/design-system-components/components").HdsAdvancedTableHorizontalAlignment;
        isVisuallyHidden?: boolean;
        label: string;
        sortingFunction?: import("@hashicorp/design-system-components/components").HdsAdvancedTableSortingFunction<unknown>;
        tooltip?: string;
        minWidth?: `${number}px`;
        maxWidth?: `${number}px`;
        alwaysVisible?: boolean;
        secondaryKey?: string;
        component?: TOC<CellRendererBaseSignature>;
        secondaryComponent?: TOC<CellRendererBaseSignature>;
        renderCondition?: (data: Record<string, unknown>) => boolean;
    })[];
}
export {};
