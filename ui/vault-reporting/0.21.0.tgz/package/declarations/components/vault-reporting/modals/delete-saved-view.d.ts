import Component from '@glimmer/component';
export interface DeleteSavedViewModalSignature {
    Args: {
        onClose?: () => void;
        onDelete?: () => Promise<unknown>;
        savedViewName: string;
        isDeleting?: boolean;
    };
    Blocks: {
        default: [];
    };
    Element: HTMLElement;
}
export default class DeleteSavedViewModal extends Component<DeleteSavedViewModalSignature> {
    handleDelete: () => Promise<void>;
}
