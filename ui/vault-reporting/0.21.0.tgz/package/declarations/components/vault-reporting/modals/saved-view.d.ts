import Component from '@glimmer/component';
import { type IntlService } from 'ember-intl';
import { type FormErrors } from '../../../utils/parse-form-errors.ts';
export interface SavedViewModalSignature {
    Args: {
        onClose?: () => void;
        onSave?: (value: {
            name: string;
            description: string;
        }) => Promise<void> | void;
        currentName?: string;
        currentDescription?: string;
        mode?: 'create' | 'rename' | 'full-update';
    };
    Blocks: {
        default: [];
    };
    Element: HTMLElement;
}
export default class SavedViewModal extends Component<SavedViewModalSignature> {
    readonly intl: IntlService;
    errors: FormErrors;
    isSaving: boolean;
    get modalTitle(): string;
    get submitButtonText(): string;
    handleSubmit: (e: Event) => Promise<void>;
    handleNameBlur: (e: FocusEvent) => void;
    hasErrors: (field: "name" | "description") => boolean | undefined;
    validateName: (name: string) => void;
}
