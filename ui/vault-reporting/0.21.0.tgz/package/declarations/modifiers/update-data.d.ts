import type { Filter } from '../utils/filters';
/**
 * Copyright IBM Corp. 2025
 * SPDX-License-Identifier: BUSL-1.1
 */
/**
 * Applies and updates a custom CSS property based on updates to a tracked/computed ember value.
 */
declare const _default: import("ember-modifier").FunctionBasedModifier<{
    Args: {
        Positional: [(filters: Filter[]) => void, Filter<Record<string, unknown>>[]];
        Named: import("ember-modifier/-private/signature").EmptyObject;
    };
    Element: HTMLElement;
}>;
export default _default;
