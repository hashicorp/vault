/**
 * Copyright IBM Corp. 2025
 * SPDX-License-Identifier: BUSL-1.1
 */
export interface SimpleDatum {
    value: number;
    label: string;
}
export declare enum REPLICATION_ENABLED_STATE {
    PRIMARY = "primary",
    SECONDARY = "secondary",
    BOOTSTRAPPING = "bootstrapping"
}
export declare const REPLICATION_DISABLED_STATE = "disabled";
export interface UsageDashboardData {
    authMethods: Record<string, number>;
    leasesByAuthMethod: Record<string, number>;
    kvv1Secrets: number;
    kvv2Secrets: number;
    leaseCountQuotas: {
        globalLeaseCountQuota: {
            capacity: number;
            count: number;
            name: string;
        };
        totalLeaseCountQuotas: number;
    };
    namespaces: number;
    secretSync: {
        totalDestinations: number;
        destinations: Record<string, number>;
    };
    pki: {
        totalIssuers: number;
        totalRoles: number;
    };
    replicationStatus: {
        drPrimary: boolean;
        drState: REPLICATION_ENABLED_STATE | typeof REPLICATION_DISABLED_STATE;
        prPrimary: boolean;
        prState: REPLICATION_ENABLED_STATE | typeof REPLICATION_DISABLED_STATE;
    };
    secretEngines: Record<string, number>;
}
export interface NamespaceData {
    keys: string[];
}
export type getUsageDataFunction = (namespace?: string) => Promise<UsageDashboardData>;
export type getNamespaceDataFunction = () => Promise<NamespaceData>;
