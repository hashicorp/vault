import type { FilterFieldControl, FilterFieldDefinition } from '../components/vault-reporting/filter-bar';
import type { InventoryTableColumn } from '../components/vault-reporting/inventory-table';
import type { SavedView } from '../components/vault-reporting/saved-views/card';
type FilterFieldControlWithoutLabels<T> = Omit<FilterFieldControl<T>, 'label' | 'placeholder'>;
type FilterFieldDefinitionWithoutLabels<T> = Omit<FilterFieldDefinition<T>, 'label' | 'controls'> & {
    controls: FilterFieldControlWithoutLabels<T>[];
};
export interface InventoryViewDefinition<TRequest = Record<string, unknown>, TRow = Record<string, unknown>> {
    reportType: 'secrets-inventory' | 'certificates-inventory';
    analyticsPrefix: string;
    getRowClass?: (row?: TRow) => string;
    defaultQuickFilters: SavedView[];
    filters: FilterFieldDefinitionWithoutLabels<TRequest>[];
    columns: Omit<InventoryTableColumn<TRow>, 'label' | 'tooltip'>[];
}
export {};
