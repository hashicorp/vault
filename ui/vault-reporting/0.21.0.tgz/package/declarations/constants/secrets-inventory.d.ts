import { type VaultReportingServiceApiFetchSecretsInventoryRequest as FetchSecretsInventoryRequest, type VaultReporting20250505SecretsInventoryRow as SecretsInventoryRow } from '../clients/cloud-vault-reporting/src/index.ts';
import type { InventoryViewDefinition } from './view-definitions.ts';
export declare const secretsInventoryViewDefinition: InventoryViewDefinition<FetchSecretsInventoryRequest, SecretsInventoryRow>;
