import type { InventoryViewDefinition } from './view-definitions';
import { type VaultReportingServiceApiFetchCertificatesInventoryRequest as FetchCertificatesInventoryRequest, type VaultReporting20250505CertificatesInventoryRow as CertificatesInventoryRow } from '../clients/cloud-vault-reporting/src/index.ts';
export declare const certificatesInventoryViewDefinition: InventoryViewDefinition<FetchCertificatesInventoryRequest, CertificatesInventoryRow & {
    status?: string;
}>;
