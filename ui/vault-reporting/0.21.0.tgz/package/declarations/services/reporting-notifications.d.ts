/**
 * Copyright IBM Corp. 2025
 * SPDX-License-Identifier: BUSL-1.1
 */
import Service from '@ember/service';
type FlashMessagesService = {
    success: (message: string, options?: object) => void;
    error: (message: string, options?: object) => void;
    warning: (message: string, options?: object) => void;
    info: (message: string, options?: object) => void;
};
/**
 * This service is used to look up the `flashMessages` service in the host application and send out notifications if it exists. If it doesn't exist
 * or the implementation breaks it falls back gracefully to do nothing. This lets us use the host application's notification system which at time of writing is the ember-cli-flash addon.
 */
export default class ReportingNotifications extends Service {
    get flashMessages(): FlashMessagesService | undefined;
    private callFlashMethod;
    info(message: string, options?: object): void;
    success(message: string, options?: object): void;
    error(message: string, options?: object): void;
    warning(message: string, options?: object): void;
}
declare module '@ember/service' {
    interface Registry {
        reportingNotifications: ReportingNotifications;
    }
}
export {};
