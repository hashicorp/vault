/**
 * Copyright IBM Corp. 2025
 * SPDX-License-Identifier: BUSL-1.1
 */
import Service from '@ember/service';
import { VaultReportingServiceApi } from '../clients/cloud-vault-reporting/src/apis/VaultReportingServiceApi.ts';
import type { Filter } from '../utils/filters.ts';
import { Configuration } from '../clients/cloud-vault-reporting/src/runtime.ts';
import type Owner from '@ember/owner';
export default class ReportingApiService extends Service {
    #private;
    /**
     * Attempt to look up the API service from host application if it exists. Using service decorator would error so this allows falling back if it doesn't.
     */
    get api(): {
        config: (basePath: string) => Configuration;
    } | undefined;
    /**
     * Attempt to look up the user context from host application if it exists. Using service decorator would error so this allows falling back if it doesn't.
     */
    get userContext(): {
        organization: {
            id: string;
        };
        project: {
            id: string;
        };
    } | undefined;
    /**
     * Attempt to get the organizationId and projectId from user context in host application.
     * Fall back to default values if not available.
     */
    get organizationId(): string;
    get projectId(): string;
    /**
     * Attempt to get the API configuration from host application. Fall back to default otherwise.
     */
    get config(): Configuration;
    reporting: VaultReportingServiceApi;
    constructor(owner: Owner);
    fetchInventory(reportType: 'secrets-inventory' | 'certificates-inventory', requestParams: Record<string, unknown>, clusterId: string): Promise<{
        data: import("../clients/cloud-vault-reporting/src/index.ts").VaultReporting20250505SecretsInventoryRow[];
        pagination: import("../clients/cloud-vault-reporting/src/index.ts").CommonPaginationResponse | undefined;
        reportAsOf: Date;
        lastScanCompletedAt: Date | undefined;
    } | {
        data: import("../clients/cloud-vault-reporting/src/index.ts").VaultReporting20250505CertificatesInventoryRow[];
        pagination: import("../clients/cloud-vault-reporting/src/index.ts").CommonPaginationResponse | undefined;
        reportAsOf: Date;
        lastScanCompletedAt: Date | undefined;
    }>;
    fetchCount(reportType: 'secrets-inventory' | 'certificates-inventory', requestParams: Record<string, unknown>, clusterId: string): Promise<number>;
    searchDistinctValues(field: string, search: string, clusterId: string, reportType: 'secrets-inventory' | 'certificates-inventory'): Promise<{
        name: string;
        value: string;
    }[]>;
    saveSavedView({ mode, reportType, clusterId, savedViewId, name, description, appliedFilters, columns, sorting, }: {
        mode: 'create' | 'rename' | 'full-update';
        reportType: 'secrets-inventory' | 'certificates-inventory';
        clusterId: string;
        savedViewId?: string;
        name: string;
        description: string;
        appliedFilters?: Filter[];
        columns?: string[];
        sorting?: {
            orderBy: string[];
        };
    }): Promise<import("../clients/cloud-vault-reporting/src/index.ts").VaultReporting20250505CreateSavedViewResponse>;
}
