import type { InventoryTarget } from './inventory-target.ts';
import { type VaultReportingServiceApiFetchCertificatesInventoryCountRequest as FetchCertificatesInventoryCountRequest, type VaultReportingServiceApiFetchCertificatesInventoryRequest as FetchCertificatesInventoryRequest, type VaultReporting20250505CertificatesInventoryRow as CertificatesInventoryRow } from '../../clients/cloud-vault-reporting/src/index.ts';
import type ReportingApiService from '../../services/reporting-api.ts';
export declare class CertificatesInventoryAdapter implements InventoryTarget<FetchCertificatesInventoryRequest, FetchCertificatesInventoryCountRequest, CertificatesInventoryRow> {
    private reportingApi;
    constructor(reportingApi: ReportingApiService);
    fetchInventory(requestParams: FetchCertificatesInventoryRequest): Promise<{
        data: CertificatesInventoryRow[];
        pagination: import("../../clients/cloud-vault-reporting/src/index.ts").CommonPaginationResponse | undefined;
        reportAsOf: Date;
        lastScanCompletedAt: Date | undefined;
    }>;
    fetchCount(requestParams: FetchCertificatesInventoryCountRequest): Promise<number>;
}
