import type { CommonPaginationRequest } from '../../clients/cloud-vault-reporting/src';
export interface InventoryTarget<TRequest = Record<string, unknown>, TCountRequest = Record<string, unknown>, TRow = Record<string, unknown>> {
    fetchInventory(requestParams: TRequest): Promise<{
        data: TRow[];
        pagination?: CommonPaginationRequest;
        reportAsOf: Date;
        lastScanCompletedAt?: Date;
    }>;
    fetchCount(requestParams: TCountRequest): Promise<number>;
}
