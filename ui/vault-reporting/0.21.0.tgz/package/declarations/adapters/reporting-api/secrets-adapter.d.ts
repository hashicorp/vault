import type { InventoryTarget } from './inventory-target.ts';
import { type VaultReportingServiceApiFetchSecretsInventoryCountRequest as FetchSecretsInventoryCountRequest, type VaultReportingServiceApiFetchSecretsInventoryRequest as FetchSecretsInventoryRequest, type VaultReporting20250505SecretsInventoryRow as SecretsInventoryRow } from '../../clients/cloud-vault-reporting/src/index.ts';
import type ReportingApiService from '../../services/reporting-api.ts';
export declare class SecretsInventoryAdapter implements InventoryTarget<FetchSecretsInventoryRequest, FetchSecretsInventoryCountRequest, SecretsInventoryRow> {
    private reportingApi;
    constructor(reportingApi: ReportingApiService);
    fetchInventory(requestParams: FetchSecretsInventoryRequest): Promise<{
        data: SecretsInventoryRow[];
        pagination: import("../../clients/cloud-vault-reporting/src/index.ts").CommonPaginationResponse | undefined;
        reportAsOf: Date;
        lastScanCompletedAt: Date | undefined;
    }>;
    fetchCount(requestParams: FetchSecretsInventoryCountRequest): Promise<number>;
}
